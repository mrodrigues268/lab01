package org.example;

import java.time.LocalDateTime;

public class Sessao {
    private String nomeFilme;
    private LocalDateTime datahora;
    private Sala sala; // Associação

    public Sessao(String nomeFilme, LocalDateTime datahora, Sala sala) {
        this.nomeFilme = nomeFilme;
        this.datahora = datahora;
        this.sala = sala;
    }

    public String getNomeFilme() { return nomeFilme; }
    public LocalDateTime getDatahora() { return datahora; }
    public Sala getSala() { return sala; }
}