package org.example;
import java.util.ArrayList;
import java.util.List;

public class Sala {
    private int numero;
    private List<Lugar> lugares; // Composição

    public Sala(int numero) {
        this.numero = numero;
        this.lugares = new ArrayList<>();
    }

    public void addLugar(char fila, int numeroLugar) {
        lugares.add(new Lugar(fila, numeroLugar));
    }

    public int getNumero() { return numero; }
    public List<Lugar> getLugares() { return lugares; }
}