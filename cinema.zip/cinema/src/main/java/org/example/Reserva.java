package org.example;

import java.util.List;

public class Reserva {
    private int id;
    private Cliente cliente;
    private Sessao sessao;
    private List<Lugar> lugaresReservados; // Lugares escolhidos na sessão

    public Reserva(int id, Cliente cliente, Sessao sessao, List<Lugar> lugaresReservados) {
        this.id = id;
        this.cliente = cliente;
        this.sessao = sessao;
        this.lugaresReservados = lugaresReservados;
    }

    public int getId() { return id; }
    public Cliente getCliente() { return cliente; }
    public Sessao getSessao() { return sessao; }
    public List<Lugar> getLugaresReservados() { return lugaresReservados; }
}