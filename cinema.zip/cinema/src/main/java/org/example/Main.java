package org.example;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // 1. Criar uma Sala e adicionar Lugares (Composição)
        Sala sala1 = new Sala(1);
        sala1.addLugar('A', 1);
        sala1.addLugar('A', 2);
        sala1.addLugar('A', 3);
        sala1.addLugar('B', 1);
        sala1.addLugar('B', 2);

        // 2. Criar uma Sessão associada à Sala (Associação)
        LocalDateTime horario = LocalDateTime.of(2026, 6, 15, 21, 30);
        Sessao sessao1 = new Sessao("Inception", horario, sala1);

        // 3. Criar um Cliente
        Cliente cliente1 = new Cliente("Ana Silva", "912345678");

        // 4. Selecionar lugares para a reserva (por exemplo, os lugares A1 e A2)
        List<Lugar> lugaresEscolhidos = new ArrayList<>();
        for (Lugar l : sala1.getLugares()) {
            if (l.getFila() == 'A' && (l.getNumero() == 1 || l.getNumero() == 2)) {
                lugaresEscolhidos.add(l);
            }
        }

        // 5. Efetuar a Reserva
        Reserva reserva1 = new Reserva(1, cliente1, sessao1, lugaresEscolhidos);

        // 6. Imprimir os detalhes para verificar se tudo funciona
        System.out.println("=== SISTEMA DE RESERVAS DE CINEMA ===");
        System.out.println("Filme: " + reserva1.getSessao().getNomeFilme());
        System.out.println("Data/Hora: " + reserva1.getSessao().getDatahora());
        System.out.println("Sala nº: " + reserva1.getSessao().getSala().getNumero());
        System.out.println("Cliente: " + reserva1.getCliente().getNome() + " (Tel: " + reserva1.getCliente().getTelefone() + ")");
        System.out.println("Lugares reservados:");
        for (Lugar l : reserva1.getLugaresReservados()) {
            System.out.println(" - Fila " + l.getFila() + ", Lugar " + l.getNumero());
        }
    }
}