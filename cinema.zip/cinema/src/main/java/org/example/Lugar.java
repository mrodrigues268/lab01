package org.example;


public class Lugar {
    private char fila;
    private int numero;

    public Lugar(char fila, int numero) {
        this.fila = fila;
        this.numero = numero;
    }

    public char getFila() { return fila; }
    public int getNumero() { return numero; }
}
